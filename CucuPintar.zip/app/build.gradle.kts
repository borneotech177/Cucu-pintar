plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.borneotech.asistennenek"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.borneotech.asistennenek"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    signingConfigs {
        create("tetap") {
            storeFile = file("cucupintar.p12")
            storeType = "pkcs12"
            storePassword = "cucupintar123"
            keyAlias = "cucupintar"
            keyPassword = "cucupintar123"
        }
    }
    buildTypes {
        // Kunci yang sama setiap build, supaya APK baru bisa menimpa (update) APK lama
        getByName("debug") { signingConfig = signingConfigs.getByName("tetap") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
