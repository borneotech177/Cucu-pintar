package com.borneotech.asistennenek

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Build
import java.util.*

/** Perhitungan waktu salat (metode Kemenag RI: Subuh 20°, Isya 18°, Ashar standar, ihtiyath +2 menit). */
object Salat {
    private fun rad(d: Double) = Math.toRadians(d)
    private fun deg(r: Double) = Math.toDegrees(r)
    private fun dsin(d: Double) = Math.sin(rad(d))
    private fun dcos(d: Double) = Math.cos(rad(d))
    private fun dtan(d: Double) = Math.tan(rad(d))
    private fun fixA(a: Double) = a - 360.0 * Math.floor(a / 360.0)
    private fun fixH(a: Double) = a - 24.0 * Math.floor(a / 24.0)

    private fun julian(y0: Int, m0: Int, d: Int): Double {
        var y = y0; var m = m0
        if (m <= 2) { y -= 1; m += 12 }
        val a = Math.floor(y / 100.0); val b = 2 - a + Math.floor(a / 4.0)
        return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + b - 1524.5
    }

    private fun sun(jd: Double): Pair<Double, Double> { // (deklinasi, equation of time)
        val dd = jd - 2451545.0
        val g = fixA(357.529 + 0.98560028 * dd); val q = fixA(280.459 + 0.98564736 * dd)
        val l = fixA(q + 1.915 * dsin(g) + 0.020 * dsin(2 * g)); val e = 23.439 - 0.00000036 * dd
        val ra = fixH(deg(Math.atan2(dcos(e) * dsin(l), dcos(l))) / 15.0)
        return deg(Math.asin(dsin(e) * dsin(l))) to (q / 15.0 - ra)
    }

    private fun mid(jd: Double, t: Double) = fixH(12 - sun(jd + t).second)

    private fun sat(jd: Double, lat: Double, ang: Double, t: Double, ccw: Boolean): Double {
        val dec = sun(jd + t).first; val noon = mid(jd, t)
        val v = deg(Math.acos((-dsin(ang) - dsin(dec) * dsin(lat)) / (dcos(dec) * dcos(lat)))) / 15.0
        return noon + if (ccw) -v else v
    }

    private fun asr(jd: Double, lat: Double, f: Double, t: Double): Double {
        val dec = sun(jd + t).first
        val ang = -deg(Math.atan(1.0 / (f + dtan(Math.abs(lat - dec)))))
        return sat(jd, lat, ang, t, false)
    }

    /** Jam desimal lokal: Subuh, Dzuhur, Ashar, Maghrib, Isya */
    fun hitung(y: Int, m: Int, d: Int, lat: Double, lng: Double, tz: Double): DoubleArray {
        val jd = julian(y, m, d) - lng / 360.0
        val r = doubleArrayOf(
            sat(jd, lat, 20.0, 5 / 24.0, true), mid(jd, 12 / 24.0), asr(jd, lat, 1.0, 13 / 24.0),
            sat(jd, lat, 0.833, 18 / 24.0, false), sat(jd, lat, 18.0, 18 / 24.0, false)
        )
        return DoubleArray(5) { r[it] + tz - lng / 15.0 }
    }
}

object Jadwal {
    val NAMA = listOf("Subuh", "Dzuhur", "Ashar", "Maghrib", "Isya")

    // Bawaan: Bengkayang, Kalimantan Barat. Bila lokasi hp diketahui, memakai lokasi hp.
    fun lokasi(c: Context): Pair<Double, Double> {
        try {
            if (c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                val lm = c.getSystemService(LocationManager::class.java)
                val l = listOf("gps", "network", "passive")
                    .mapNotNull { try { lm.getLastKnownLocation(it) } catch (e: Exception) { null } }
                    .maxByOrNull { it.time }
                if (l != null) return l.latitude to l.longitude
            }
        } catch (e: Exception) { }
        return 0.9015 to 109.4850
    }

    fun waktuHari(c: Context, tambahHari: Int = 0): List<Pair<String, Calendar>> {
        val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, tambahHari) }
        val (lat, lng) = lokasi(c)
        val tz = TimeZone.getDefault().getOffset(cal.timeInMillis) / 3600000.0
        val h = Salat.hitung(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH), lat, lng, tz)
        return NAMA.indices.map { i ->
            val k = (cal.clone() as Calendar).apply {
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                add(Calendar.MINUTE, Math.round(h[i] * 60).toInt() + 2)
            }
            NAMA[i] to k
        }
    }

    fun berikutnya(c: Context, jeda: Long = 0): Pair<String, Calendar> {
        val n = System.currentTimeMillis() + jeda
        return (0..1).flatMap { waktuHari(c, it) }.first { it.second.timeInMillis > n }
    }

    /** Pasang alarm untuk waktu salat berikutnya. Dipanggil saat aplikasi dibuka, setelah alarm bunyi, dan setelah hp menyala. */
    fun atur(c: Context) {
        val next = berikutnya(c, 60_000)
        val am = c.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(
            c, 77, Intent(c, AzanReceiver::class.java).putExtra("nama", next.first),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val t = next.second.timeInMillis
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
        else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
    }
}
