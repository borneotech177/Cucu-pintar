package com.borneotech.asistennenek

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager

object Baterai {
    /** Cek baterai tiap ±15 menit. */
    fun atur(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(
            c, 78, Intent(c, BateraiReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 15 * 60 * 1000L, pi)
    }
}

class BateraiReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val b = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (b != null) {
            val level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) * 100 / b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val dicas = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            val sp = c.getSharedPreferences("cp", Context.MODE_PRIVATE)
            val now = System.currentTimeMillis()
            // 1) Nenek diingatkan dengan suara (<= 20%), paling sering tiap 2 jam
            if (!dicas && level in 0..20 && now - sp.getLong("bat_nenek", 0) > 2 * 3600_000L) {
                sp.edit().putLong("bat_nenek", now).apply()
                try {
                    c.startForegroundService(
                        Intent(c, AzanService::class.java)
                            .putExtra("umum", "Baterai tinggal $level persen. Tolong dicas ya, ${MainActivity.NAME}")
                    )
                } catch (e: Exception) { }
            }
            // 2) Keluarga dikabari lewat WhatsApp (<= 15%), paling sering tiap 6 jam
            if (!dicas && level in 0..15 && sp.getBoolean("bat_keluarga", true) && now - sp.getLong("bat_keluarga_t", 0) > 6 * 3600_000L) {
                val nomor = sp.getStringSet("utama_nomor", emptySet())?.toList() ?: emptyList()
                val svc = DaruratService.instance
                if (nomor.isNotEmpty() && svc != null) {
                    sp.edit().putLong("bat_keluarga_t", now).apply()
                    svc.kirimKeBanyak(nomor, "Baterai hp ${MainActivity.NAME} tinggal $level%. Mohon diingatkan untuk dicas.")
                }
            }
        }
        atur(c)
    }
}
