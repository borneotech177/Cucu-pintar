package com.borneotech.asistennenek

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/**
 * Notifikasi waktu salat + suara azan.
 * Taruh file azan di res/raw: azan.mp3 (semua waktu) dan, bila mau, azan_subuh.mp3 (khusus Subuh).
 * Tanpa file azan, hanya notifikasi dan nada pemberitahuan.
 */
class AzanService : Service() {
    private var mp: MediaPlayer? = null
    private val h = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == "STOP") { selesai(true); return START_NOT_STICKY }
        val nama = i?.getStringExtra("nama") ?: "salat"

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("azan", "Waktu salat", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Pengingat waktu salat dan azan"; setSound(null, null)
            }
        )
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, AzanService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "azan")
            .setSmallIcon(R.drawable.ic_moon)
            .setContentTitle("Waktunya salat $nama")
            .setContentText("Ayo salat, ${MainActivity.NAME}")
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_close), "Matikan azan", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(77, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(77, n)

        mp?.release(); mp = null
        if (getSharedPreferences("cp", Context.MODE_PRIVATE).getBoolean("azan_on", true)) {
            var res = if (nama == "Subuh") resources.getIdentifier("azan_subuh", "raw", packageName) else 0
            if (res == 0) res = resources.getIdentifier("azan", "raw", packageName)
            if (res != 0) {
                val at = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
                mp = MediaPlayer.create(this, res, at, AudioManager.AUDIO_SESSION_ID_GENERATE)
                    ?.apply { setOnCompletionListener { selesai(false) }; start() }
            } else {
                try { RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)).play() } catch (e: Exception) { }
            }
        }
        if (mp == null) h.postDelayed({ selesai(false) }, 8000)
        return START_NOT_STICKY
    }

    private fun selesai(hapus: Boolean) {
        mp?.let { try { it.stop() } catch (e: Exception) { }; it.release() }
        mp = null
        h.removeCallbacksAndMessages(null)
        stopForeground(if (hapus) STOP_FOREGROUND_REMOVE else STOP_FOREGROUND_DETACH)
        stopSelf()
    }

    override fun onDestroy() { mp?.release(); super.onDestroy() }
}
