package com.borneotech.asistennenek

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * Notifikasi + suara.
 * - extra "nama": waktu salat -> memutar res/raw/azan.mp3 (azan_subuh.mp3 untuk Subuh).
 *   Tanpa file: nada keras (volume alarm) + pengumuman suara.
 * - extra "umum": pengumuman suara biasa (mis. baterai lemah).
 */
class AzanService : Service() {
    private var mp: MediaPlayer? = null
    private var tts: TextToSpeech? = null
    private val h = Handler(Looper.getMainLooper())
    private val alarmAttr = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == "STOP") { selesai(true); return START_NOT_STICKY }
        val umum = i?.getStringExtra("umum")
        val nama = i?.getStringExtra("nama") ?: "salat"

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("azan", "Waktu salat", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Pengingat waktu salat dan azan"; setSound(null, null)
        })
        nm.createNotificationChannel(NotificationChannel("info", "Pemberitahuan", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Pengingat suara, misalnya baterai lemah"; setSound(null, null)
        })
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, AzanService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, if (umum != null) "info" else "azan")
            .setSmallIcon(R.drawable.ic_moon)
            .setContentTitle(if (umum != null) "Cucu Pintar" else "Waktunya salat $nama")
            .setContentText(umum ?: "Ayo salat, ${MainActivity.NAME}")
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_close), "Matikan suara", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(77, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(77, n)

        mp?.release(); mp = null
        h.removeCallbacksAndMessages(null)

        if (umum != null) {
            naikkanVolume(); chime()
            h.postDelayed({ umumkan(umum) }, 2200)
            h.postDelayed({ selesai(false) }, 15000)
        } else if (getSharedPreferences("cp", Context.MODE_PRIVATE).getBoolean("azan_on", true)) {
            naikkanVolume()
            mulaiAzan(nama)
        } else h.postDelayed({ selesai(false) }, 8000)
        return START_NOT_STICKY
    }

    private fun naikkanVolume() {
        try {
            val am = getSystemService(AudioManager::class.java)
            val max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            if (am.getStreamVolume(AudioManager.STREAM_ALARM) < max * 0.6) am.setStreamVolume(AudioManager.STREAM_ALARM, (max * 0.7).toInt(), 0)
        } catch (e: Exception) { }
    }

    private fun chime() {
        try {
            RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                .apply { audioAttributes = alarmAttr; play() }
        } catch (e: Exception) { }
    }

    private fun mulaiAzan(nama: String) {
        var res = if (nama == "Subuh") resources.getIdentifier("azan_subuh", "raw", packageName) else 0
        if (res == 0) res = resources.getIdentifier("azan", "raw", packageName)
        if (res != 0) {
            mp = MediaPlayer.create(this, res, alarmAttr, AudioManager.AUDIO_SESSION_ID_GENERATE)
                ?.apply { setOnCompletionListener { selesai(false) }; start() }
            if (mp != null) return
        }
        chime()
        h.postDelayed({ umumkan("Waktunya salat $nama") }, 2500)
        h.postDelayed({ selesai(false) }, 12000)
    }

    private fun umumkan(teks: String) {
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts?.language = Locale("id", "ID")
                tts?.setAudioAttributes(alarmAttr)
                tts?.speak(teks, TextToSpeech.QUEUE_FLUSH, null, "umum")
            }
        }
    }

    private fun selesai(hapus: Boolean) {
        mp?.let { try { it.stop() } catch (e: Exception) { }; it.release() }
        mp = null
        tts?.shutdown(); tts = null
        h.removeCallbacksAndMessages(null)
        stopForeground(if (hapus) STOP_FOREGROUND_REMOVE else STOP_FOREGROUND_DETACH)
        stopSelf()
    }

    override fun onDestroy() { mp?.release(); tts?.shutdown(); super.onDestroy() }
}
