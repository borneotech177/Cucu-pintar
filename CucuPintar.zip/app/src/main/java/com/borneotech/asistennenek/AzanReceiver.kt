package com.borneotech.asistennenek

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AzanReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val nama = i.getStringExtra("nama")
        if (nama != null) {
            try { c.startForegroundService(Intent(c, AzanService::class.java).putExtra("nama", nama)) } catch (e: Exception) { }
        }
        Jadwal.atur(c) // jadwalkan salat berikutnya (juga setelah hp dinyalakan ulang / aplikasi diperbarui)
    }
}
