package com.borneotech.asistennenek

import android.Manifest
import android.app.Activity
import android.app.Dialog
import android.app.WallpaperManager
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.Settings
import android.text.InputType
import android.location.LocationManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

/**
 * Cucu Pintar - launcher untuk nenek.
 * Panggilan utama lewat WhatsApp (suara/video), cadangan telepon biasa.
 * Suara: "telepon Budi", "video Budi", "pesan Budi", "cari nomor Budi",
 *        "tambah nomor Budi 0812...", "putar ceramah ...", "ganti latar", "jam berapa".
 * Kalau nama kurang jelas, aplikasi menampilkan pilihan (tidak menebak).
 */
class MainActivity : Activity(), TextToSpeech.OnInitListener {

    companion object { const val NAME = "Nenek" }

    data class Kontak(val nama: String, val nomor: String)
    data class Pilihan(val ikon: Int, val label: String, val gambar: android.graphics.drawable.Drawable? = null, val aksi: () -> Unit)
    enum class Aksi { TELEPON, VIDEO, CHAT, CARI }

    private lateinit var tts: TextToSpeech
    private lateinit var status: TextView
    private lateinit var hello: TextView
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private val locale = Locale("id", "ID")
    private val REQ_SPEECH = 1
    private val REQ_PERM = 2
    private val REQ_ROLE = 3
    private val REQ_WP = 4
    private val REQ_PICK = 5
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { updateClock(); handler.postDelayed(this, 10000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.TRANSPARENT
        tts = TextToSpeech(this, this)
        buildUi()
        requestPermissions(
            arrayOf(
                Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.WRITE_CONTACTS, Manifest.permission.POST_NOTIFICATIONS
            ), REQ_PERM
        )
    }

    override fun onResume() { super.onResume(); handler.post(tick); Jadwal.atur(this); Baterai.atur(this); simpanUtama(); aktifkanAksesibilitas() }
    override fun onPause() { handler.removeCallbacks(tick); super.onPause() }
    override fun onInit(s: Int) { tts.language = locale; tts.setSpeechRate(0.85f) }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == REQ_PERM) { Jadwal.atur(this); askHome() }
    }

    private fun askHome() {
        if (Build.VERSION.SDK_INT >= 29) {
            val rm = getSystemService(android.app.role.RoleManager::class.java)
            if (rm.isRoleAvailable(android.app.role.RoleManager.ROLE_HOME) &&
                !rm.isRoleHeld(android.app.role.RoleManager.ROLE_HOME)
            ) startActivityForResult(rm.createRequestRoleIntent(android.app.role.RoleManager.ROLE_HOME), REQ_ROLE)
        }
    }

    @Deprecated("launcher")
    override fun onBackPressed() {}

    private fun say(t: String) { status.text = t; tts.speak(t, TextToSpeech.QUEUE_ADD, null, "a") }

    // Setiap menu ditekan, namanya langsung dibacakan (bisa dimatikan keluarga di menu Khusus keluarga)
    private fun bacaMenu(label: String) {
        if (prefs().getBoolean("baca_menu", true))
            tts.speak(label.replace("(", ", ").replace(")", ""), TextToSpeech.QUEUE_FLUSH, null, "menu")
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun hasContacts() = checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    private fun updateClock() {
        val d = Date(); val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        hello.text = (if (h < 11) "Selamat pagi" else if (h < 15) "Selamat siang" else if (h < 18) "Selamat sore" else "Selamat malam") + ", $NAME"
        clock.text = SimpleDateFormat("HH:mm", locale).format(d)
        date.text = SimpleDateFormat("EEEE, d MMMM yyyy", locale).format(d)
    }

    // ================= UI =================
    private fun tile(
        icon: Int, label: String, badge: String, h: Int = 132, wide: Boolean = false,
        border: String = "#4A7FB5", ink: String = "#2D5C8F",
        iconDrawable: android.graphics.drawable.Drawable? = null, onClick: () -> Unit
    ): View = LinearLayout(this).apply {
        orientation = if (wide) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#FFFBF2")); cornerRadius = dp(28).toFloat(); setStroke(dp(3), Color.parseColor(border))
        }
        elevation = dp(4).toFloat()
        layoutParams = (if (wide) LinearLayout.LayoutParams(-1, dp(h)) else LinearLayout.LayoutParams(0, dp(h), 1f))
            .apply { setMargins(dp(6), dp(6), dp(6), dp(6)) }
        setPadding(dp(12), dp(8), dp(12), dp(8))
        val sz = if (wide) 58 else 62
        addView(ImageView(context).apply {
            if (iconDrawable != null) setImageDrawable(iconDrawable) else setImageResource(icon)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor(badge)); setStroke(dp(2), Color.parseColor(border)) }
            layoutParams = LinearLayout.LayoutParams(dp(sz), dp(sz)).apply { if (wide) rightMargin = dp(14) else bottomMargin = dp(6) }
        })
        addView(TextView(context).apply {
            text = label; textSize = if (wide) 21f else 18f; setTextColor(Color.parseColor(ink))
            typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        })
        isClickable = true
        setOnClickListener { bacaMenu(label); onClick() }
        setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(80).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
            }
            false
        }
    }

    private fun row(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        v.forEach { addView(it) }
    }

    private fun txt(size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        textSize = size; setTextColor(color); gravity = Gravity.CENTER
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setShadowLayer(4f, 0f, 2f, Color.argb(140, 0, 0, 0))
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(28), dp(10), dp(20)) }
        hello = TextView(this).apply {
            textSize = 18f; setTextColor(Color.parseColor("#2D5C8F")); gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        clock = TextView(this).apply {
            textSize = 56f; setTextColor(Color.parseColor("#1F3F66")); gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }
        date = TextView(this).apply { textSize = 16f; setTextColor(Color.parseColor("#5B7FA6")); gravity = Gravity.CENTER }
        status = TextView(this).apply {
            textSize = 17f; setTextColor(Color.parseColor("#C2571A")); gravity = Gravity.CENTER
            text = "Tekan “Bicara ke Cucu”, lalu ucapkan: telepon Budi"; setPadding(dp(8), dp(8), dp(8), 0)
        }
        root.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.argb(238, 255, 251, 242)); cornerRadius = dp(30).toFloat(); setStroke(dp(3), Color.parseColor("#4A7FB5"))
            }
            setPadding(dp(16), dp(12), dp(16), dp(12))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(6), 0, dp(6), dp(8)) }
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                addView(ImageView(context).apply {
                    setImageResource(R.drawable.logo_cucu_pintar)
                    layoutParams = LinearLayout.LayoutParams(dp(96), dp(96)).apply { rightMargin = dp(12) }
                })
                addView(LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                    addView(hello); addView(clock); addView(date)
                })
            })
            addView(status)
        })
        root.addView(tile(R.drawable.ic_mic, "Bicara ke Cucu", "#E4DAFB", 92, true) { listen() })
        root.addView(tile(R.drawable.ic_family, "Keluarga", "#FFE0B8", 92, true) { showKeluarga() })
        root.addView(row(
            tile(R.drawable.ic_chat_bubble, "WhatsApp", "#CDEFD0") { openPkg("com.whatsapp", "WhatsApp") },
            tile(R.drawable.ic_play, "YouTube", "#FFD9D2") { openPkg("com.google.android.youtube", "YouTube") }
        ))
        root.addView(row(
            tile(R.drawable.ic_photo, "Foto", "#FFF0C2") { openGallery() },
            tile(R.drawable.ic_camera, "Kamera", "#E4DAFB") { startSafe(Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }
        ))
        root.addView(row(
            tile(R.drawable.ic_search, "Cari Kontak", "#CFE6FA") { openContactList() },
            tile(R.drawable.ic_person_add, "Tambah Nomor", "#C9EFEA") { showTambah() }
        ))
        root.addView(row(
            tile(R.drawable.ic_book, "Putar Ceramah", "#FFE0B8") { youtube("ceramah ustadz terbaru") },
            tile(R.drawable.ic_moon, "Waktu Salat", "#FFF0C2") { showSalat() }
        ))
        root.addView(row(
            tile(R.drawable.ic_flash, "Senter", "#FFF0C2") { senter() },
            tile(R.drawable.ic_pin, "Kirim Lokasi", "#CFE6FA") { kirimLokasi() }
        ))
        root.addView(tile(R.drawable.ic_apps, "Aplikasi Lain", "#E4E8F7", 76, true) { showApps() })
        root.addView(row(
            tile(R.drawable.ic_wallpaper, "Ganti Latar", "#D8F0D5", 110) { pickWallpaper() },
            tile(R.drawable.ic_warning, "TOLONG", "#FFD9D2", 110, false, "#E0453A", "#C62828") { confirmSos() }
        ))
        setContentView(ScrollView(this).apply { addView(root); isFillViewport = true })
    }

    // ---------- Dialog pilihan besar ----------
    private fun showChoices(title: String, items: List<Pilihan>) {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(16), dp(10), dp(10)) }
        box.addView(TextView(this).apply {
            text = title; textSize = 23f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#2D5C8F")); setPadding(dp(8), 0, dp(8), dp(10))
        })
        val pal = listOf("#CDEFD0", "#CFE6FA", "#E4DAFB", "#FFE0B8", "#FFF0C2")
        items.forEachIndexed { i, p ->
            box.addView(tile(p.ikon, p.label, pal[i % pal.size], 76, true, iconDrawable = p.gambar) { d.dismiss(); p.aksi() })
        }
        box.addView(tile(R.drawable.ic_close, "Tutup", "#E3E8EE", 60, true, "#9AA5B1", "#5F6B7A") { d.dismiss() })
        d.setContentView(ScrollView(this).apply { addView(box) })
        d.window?.setBackgroundDrawable(GradientDrawable().apply {
            setColor(Color.parseColor("#FFF4DC")); cornerRadius = dp(30).toFloat(); setStroke(dp(3), Color.parseColor("#4A7FB5"))
        })
        d.window?.setLayout((resources.displayMetrics.widthPixels * 0.94).toInt(), WindowManager.LayoutParams.WRAP_CONTENT)
        d.show()
    }

    // Menu orang: telepon / video / pesan WhatsApp, telepon biasa, jadikan kontak utama
    private fun showMenu(k: Kontak) {
        val utama = isUtama(k)
        showChoices(k.nama, listOf(
            Pilihan(R.drawable.ic_phone, "Telepon WhatsApp") { doAksi(Aksi.TELEPON, k) },
            Pilihan(R.drawable.ic_videocam, "Video WhatsApp") { doAksi(Aksi.VIDEO, k) },
            Pilihan(R.drawable.ic_chat, "Pesan WhatsApp") { doAksi(Aksi.CHAT, k) },
            Pilihan(R.drawable.ic_phone, "Telepon Biasa") { call(k.nomor) },
            Pilihan(R.drawable.ic_star, if (utama) "Hapus dari kontak utama" else "Jadikan kontak utama") { setUtama(k, !utama) }
        ))
    }

    private fun showContactList(all: List<Kontak>, onPick: (Kontak) -> Unit) {
        if (all.isEmpty()) { say("Kontak belum ada atau belum diizinkan"); return }
        showChoices("Pilih nama", all.map { k -> Pilihan(R.drawable.ic_person, k.nama) { onPick(k) } })
    }

    private fun openContactList() = showContactList(loadContacts()) { showMenu(it) }

    // ---------- Menu dalam menu: Keluarga (kontak utama) -> orangnya -> telepon / video ----------
    private fun showKeluarga() {
        val fam = sosRecipients()
        if (fam.isEmpty()) {
            say("Belum ada kontak utama. Silakan tambahkan")
            showChoices("Keluarga", listOf(Pilihan(R.drawable.ic_star, "Tambah kontak utama") { tambahKeluarga() }))
            return
        }
        val items = fam.map { k -> Pilihan(R.drawable.ic_person, k.nama) { showMenu(k) } }.toMutableList()
        items.add(Pilihan(R.drawable.ic_star, "Tambah kontak utama") { tambahKeluarga() })
        showChoices("Keluarga", items)
    }

    private fun tambahKeluarga() = showContactList(loadContacts()) { setUtama(it, true) }

    private fun isUtama(k: Kontak) = sosRecipients().any { it.nama == k.nama }

    private fun setUtama(k: Kontak, v: Boolean) {
        if (checkSelfPermission(Manifest.permission.WRITE_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            say("Izin mengubah kontak belum diberikan"); return
        }
        var id: Long? = null
        contentResolver.query(Phone.CONTENT_URI, arrayOf(Phone.CONTACT_ID), "${Phone.DISPLAY_NAME}=?", arrayOf(k.nama), null)
            ?.use { if (it.moveToFirst()) id = it.getLong(0) }
        val cid = id ?: run { say("Kontak tidak ditemukan"); return }
        val cv = ContentValues().apply { put(ContactsContract.Contacts.STARRED, if (v) 1 else 0) }
        val n = contentResolver.update(ContactsContract.Contacts.CONTENT_URI, cv, "${ContactsContract.Contacts._ID}=?", arrayOf(cid.toString()))
        if (n > 0) simpanUtama()
        say(if (n > 0) (if (v) "${k.nama} jadi kontak utama" else "${k.nama} dihapus dari kontak utama") else "Gagal mengubah kontak")
    }

    // ---------- Tambah nomor: ambil dari kontak hp, atau buat baru ----------
    private fun showTambah() = showChoices("Tambah Nomor", listOf(
        Pilihan(R.drawable.ic_search, "Ambil dari kontak hp") { pilihKontakHp() },
        Pilihan(R.drawable.ic_person_add, "Buat kontak baru") { addContact(emptyList()) }
    ))

    private fun pilihKontakHp() {
        say("Pilih nama dari daftar kontak")
        try { startActivityForResult(Intent(Intent.ACTION_PICK, Phone.CONTENT_URI), REQ_PICK) }
        catch (e: Exception) { say("Daftar kontak tidak tersedia") }
    }

    // Kontak yang dipilih jadi kontak utama (muncul di menu Keluarga)
    private fun terimaKontak(uri: Uri) {
        contentResolver.query(uri, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER), null, null, null)?.use {
            if (it.moveToFirst()) setUtama(Kontak(it.getString(0) ?: return, it.getString(1) ?: ""), true)
        }
    }

    // ---------- Aplikasi lain (di luar menu utama) ----------
    data class App(val label: String, val pkg: String)

    private fun prefs() = getSharedPreferences("cp", MODE_PRIVATE)

    // Bawaan: Pengaturan dan Play Store disembunyikan dari nenek
    private fun disembunyi(): MutableSet<String> =
        prefs().getStringSet("app_sembunyi", setOf("com.android.settings", "com.android.vending"))!!.toMutableSet()

    private fun semuaApp(): List<App> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(i, 0)
            .map { App(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != packageName }.distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
    }

    private fun ikonApp(pkg: String) = try { packageManager.getApplicationIcon(pkg) } catch (e: Exception) { null }

    private fun showApps() {
        val h = disembunyi()
        val items = semuaApp().filter { it.pkg !in h }
            .map { a -> Pilihan(R.drawable.ic_apps, a.label, ikonApp(a.pkg)) { openPkg(a.pkg, a.label) } }.toMutableList()
        items.add(Pilihan(R.drawable.ic_star, "Khusus keluarga (PIN)") { mintaPin { showAdmin() } })
        showChoices("Aplikasi Lain", items)
    }

    private fun saklar(kunci: String, label: String, def: Boolean = true): Pilihan {
        val on = prefs().getBoolean(kunci, def)
        return Pilihan(if (on) R.drawable.ic_check else R.drawable.ic_close, "$label: " + (if (on) "HIDUP" else "MATI")) {
            prefs().edit().putBoolean(kunci, !on).apply(); showAdmin()
        }
    }

    private fun showAdmin(): Unit = showChoices("Khusus keluarga", listOf(
        Pilihan(R.drawable.ic_apps, "Atur aplikasi yang tampil") { showAturApp() },
        saklar("baca_menu", "Bacakan nama menu"),
        saklar("jawab_otomatis", "Jawab panggilan WhatsApp otomatis"),
        saklar("skip_iklan", "Lewati iklan YouTube otomatis"),
        saklar("bat_keluarga", "Kabari keluarga bila baterai lemah"),
        Pilihan(R.drawable.ic_check, "Buka Pengaturan hp") { startSafe(Intent(Settings.ACTION_SETTINGS)) },
        Pilihan(R.drawable.ic_play, "Buka Play Store") { openPkg("com.android.vending", "Play Store") },
        Pilihan(R.drawable.ic_check, "Aktifkan layanan aksesibilitas") { startSafe(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
        Pilihan(R.drawable.ic_star, "Ubah PIN") { ubahPin() },
        Pilihan(R.drawable.ic_close, "Ganti layar utama (keluar)") { startSafe(Intent(Settings.ACTION_HOME_SETTINGS)) }
    ))

    private fun showAturApp() {
        val h = disembunyi()
        showChoices("Aplikasi yang tampil", semuaApp().map { a ->
            val sembunyi = a.pkg in h
            Pilihan(
                if (sembunyi) R.drawable.ic_close else R.drawable.ic_check,
                a.label + if (sembunyi) " (disembunyikan)" else " (tampil)", ikonApp(a.pkg)
            ) {
                if (sembunyi) h.remove(a.pkg) else h.add(a.pkg)
                prefs().edit().putStringSet("app_sembunyi", h).apply(); showAturApp()
            }
        })
    }

    private fun pin() = prefs().getString("pin", "1234") ?: "1234"

    private fun inputPin(judul: String, ok: (String) -> Unit) {
        val et = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD; hint = "PIN"; textSize = 24f
        }
        android.app.AlertDialog.Builder(this).setTitle(judul).setView(et)
            .setPositiveButton("OK") { _, _ -> ok(et.text.toString()) }.setNegativeButton("Batal", null).show()
    }

    private fun mintaPin(next: () -> Unit) = inputPin("Khusus keluarga: masukkan PIN") { if (it == pin()) next() else say("PIN salah") }

    private fun ubahPin() = inputPin("PIN baru (minimal 4 angka)") {
        if (it.length >= 4) { prefs().edit().putString("pin", it).apply(); say("PIN sudah diganti") } else say("PIN minimal 4 angka")
    }

    // ---------- Waktu salat & azan ----------
    private fun showSalat() {
        val sp = getSharedPreferences("cp", MODE_PRIVATE)
        val fmt = SimpleDateFormat("HH:mm", locale)
        val nx = Jadwal.berikutnya(this)
        val on = sp.getBoolean("azan_on", true)
        val items = Jadwal.waktuHari(this).map { (n, t) -> Pilihan(R.drawable.ic_moon, "$n   ${fmt.format(t.time)}") { } }.toMutableList()
        items.add(Pilihan(if (on) R.drawable.ic_check else R.drawable.ic_close, "Suara azan: " + (if (on) "HIDUP" else "MATI")) {
            sp.edit().putBoolean("azan_on", !on).apply(); showSalat()
        })
        items.add(Pilihan(R.drawable.ic_play, "Coba bunyikan azan") {
            try { startForegroundService(Intent(this, AzanService::class.java).putExtra("nama", "Dzuhur")) } catch (e: Exception) { say("Gagal membunyikan azan") }
        })
        say("Salat berikutnya ${nx.first} jam ${fmt.format(nx.second.time)}")
        showChoices("Berikutnya: ${nx.first} ${fmt.format(nx.second.time)}", items)
    }

    // ================= Kontak & pencocokan nama =================
    private fun loadContacts(): List<Kontak> {
        if (!hasContacts()) return emptyList()
        val out = LinkedHashMap<String, Kontak>()
        contentResolver.query(
            Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER), null, null, "${Phone.DISPLAY_NAME} COLLATE NOCASE ASC"
        )?.use { c ->
            while (c.moveToNext()) {
                val n = c.getString(0) ?: continue
                if (!out.containsKey(n)) out[n] = Kontak(n, c.getString(1) ?: "")
            }
        }
        return out.values.toList()
    }

    private fun norm(s: String) = s.lowercase(locale).replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()

    private fun lev(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var p = d[0]; d[0] = i
            for (j in 1..b.length) {
                val t = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, p + if (a[i - 1] == b[j - 1]) 0 else 1)
                p = t
            }
        }
        return d[b.length]
    }

    private fun sim(a: String, b: String): Double =
        if (a.isEmpty() || b.isEmpty()) 0.0 else 1.0 - lev(a, b).toDouble() / maxOf(a.length, b.length)

    private fun nameScore(q0: String, n0: String): Double {
        val q = norm(q0); val n = norm(n0)
        if (q.isEmpty() || n.isEmpty()) return 0.0
        if (q == n) return 1.0
        val qt = q.split(" "); val nt = n.split(" ")
        val tok = qt.map { t -> nt.maxOf { w -> if (w == t) 1.0 else sim(t, w) } }.average()
        val cap = if (nt.size > qt.size) 0.97 else 1.0
        return maxOf(tok * cap, sim(q, n))
    }

    private val stop = setOf(
        "telepon", "telpon", "telfon", "telefon", "hubungi", "panggil", "call", "video", "vc", "videocall", "whatsapp", "wa",
        "tolong", "ke", "dong", "ya", "mau", "saya", "aku", "pesan", "chat", "kirim", "lewat", "buka", "cari", "carikan",
        "nomor", "nya", "tambah", "simpan", "kontak", "berapa", "siapa", "yang", "di", "untuk", "bisa", "coba", "hp", "baru", "buat"
    )

    private fun strip(t: String) = norm(t).split(" ").filter { it.isNotEmpty() && it !in stop }.joinToString(" ")

    private fun rank(alts: List<String>, all: List<Kontak>): List<Pair<Kontak, Double>> {
        val qs = alts.map { strip(it) }.filter { it.isNotBlank() }.distinct()
        if (qs.isEmpty()) return emptyList()
        return all.map { k -> k to qs.maxOf { nameScore(it, k.nama) } }
            .filter { it.second >= 0.6 }.sortedByDescending { it.second }
    }

    // ================= Aksi pada kontak =================
    private fun ikon(a: Aksi) = when (a) {
        Aksi.TELEPON -> R.drawable.ic_phone; Aksi.VIDEO -> R.drawable.ic_videocam
        Aksi.CHAT -> R.drawable.ic_chat; Aksi.CARI -> R.drawable.ic_search
    }

    private fun aksi(a: Aksi, alts: List<String>, contacts: List<Kontak>) {
        if (contacts.isEmpty()) { say("Kontak belum bisa dibaca. Mohon izinkan akses kontak"); return }
        val r = rank(alts, contacts)
        when {
            r.isEmpty() -> { say("Nama tidak ketemu. Silakan pilih dari daftar"); showContactList(contacts) { doAksi(a, it) } }
            r[0].second >= 0.9 && (r.size == 1 || r[1].second < r[0].second - 0.05) -> doAksi(a, r[0].first)
            else -> {
                say("Maksudnya yang mana?")
                showChoices("Pilih nama", r.take(4).map { (k, _) -> Pilihan(ikon(a), k.nama) { doAksi(a, k) } })
            }
        }
    }

    private fun doAksi(a: Aksi, k: Kontak) {
        when (a) {
            Aksi.TELEPON ->
                if (waCall(k.nama, false)) say("Menelepon ${k.nama} lewat WhatsApp")
                else { say("${k.nama} belum punya WhatsApp. Menelepon biasa"); call(k.nomor) }
            Aksi.VIDEO -> if (waCall(k.nama, true)) say("Video call ${k.nama}") else say("${k.nama} belum punya WhatsApp")
            Aksi.CHAT -> { say("Membuka WhatsApp ${k.nama}"); startSafe(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${intl(k.nomor)}"))) }
            Aksi.CARI -> { say("Nomor ${k.nama}: " + k.nomor.filter { it.isDigit() }.toCharArray().joinToString(" ")); showMenu(k) }
        }
    }

    // Panggilan WhatsApp langsung lewat data kontak milik WhatsApp
    private fun waCall(name: String, video: Boolean): Boolean {
        if (name.isBlank() || !hasContacts()) return false
        val mime = if (video) "vnd.android.cursor.item/vnd.com.whatsapp.video.call"
                   else "vnd.android.cursor.item/vnd.com.whatsapp.voip.call"
        for (op in listOf("=", "LIKE")) {
            val arg = if (op == "=") name else "%$name%"
            contentResolver.query(
                ContactsContract.Data.CONTENT_URI, arrayOf(ContactsContract.Data._ID),
                "${ContactsContract.Data.MIMETYPE}=? AND ${ContactsContract.Data.DISPLAY_NAME} $op ?", arrayOf(mime, arg), null
            )?.use {
                if (it.moveToFirst()) {
                    val uri = Uri.parse("content://com.android.contacts/data/${it.getLong(0)}")
                    startSafe(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).setPackage("com.whatsapp"))
                    return true
                }
            }
        }
        return false
    }

    // Tambah nomor: nama/nomor dari ucapan diisi otomatis, tinggal tekan Simpan
    private fun addContact(alts: List<String>) {
        val words = mapOf("nol" to "0", "kosong" to "0", "satu" to "1", "dua" to "2", "tiga" to "3", "empat" to "4",
            "lima" to "5", "enam" to "6", "tujuh" to "7", "delapan" to "8", "sembilan" to "9")
        var s = (alts.firstOrNull() ?: "").lowercase(locale)
        words.forEach { (w, d) -> s = s.replace(Regex("\\b$w\\b"), d) }
        val m = Regex("\\+?\\d[\\d\\s\\-]{6,}\\d").find(s)
        val num = m?.value?.replace(Regex("[^\\d+]"), "") ?: ""
        val name = strip(if (m != null) s.removeRange(m.range) else s).split(" ")
            .joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }.trim()
        say(if (num.isNotEmpty()) "Menambah $name, nomor " + num.toCharArray().joinToString(" ") + ". Tekan simpan"
            else "Silakan isi nama dan nomor, lalu tekan simpan")
        val i = Intent(ContactsContract.Intents.Insert.ACTION).setType(ContactsContract.RawContacts.CONTENT_TYPE)
        if (name.isNotBlank()) i.putExtra(ContactsContract.Intents.Insert.NAME, name)
        if (num.isNotEmpty()) i.putExtra(ContactsContract.Intents.Insert.PHONE, num)
        startSafe(i)
    }

    // ================= TOLONG / lokasi: kirim ke keluarga lewat WhatsApp =================
    private fun confirmSos() {
        val items = mutableListOf(
            Pilihan(R.drawable.ic_warning, "Kirim Pesan Tolong") { mulaiSos() },
            Pilihan(R.drawable.ic_phone, "Telepon Darurat 112") { call("112") }
        )
        if (!DaruratService.aktif)
            items.add(Pilihan(R.drawable.ic_check, "Aktifkan kirim otomatis (keluarga)") { startSafe(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        say("Mau minta tolong ke keluarga?")
        showChoices("Minta tolong ke keluarga?", items)
    }

    // Kontak utama (berbintang) yang punya nomor
    private fun sosRecipients(): List<Kontak> {
        if (!hasContacts()) return emptyList()
        val out = LinkedHashMap<String, Kontak>()
        contentResolver.query(
            Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER), "${Phone.STARRED}=1", null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val n = c.getString(0) ?: continue
                val p = c.getString(1) ?: continue
                if (!out.containsKey(n)) out[n] = Kontak(n, p)
            }
        }
        return out.values.toList()
    }

    // Disimpan agar layanan aksesibilitas dan pengecek baterai tahu siapa kontak utama
    private fun simpanUtama() {
        val r = sosRecipients()
        prefs().edit().putStringSet("utama_nama", r.map { it.nama }.toSet())
            .putStringSet("utama_nomor", r.map { it.nomor }.toSet()).apply()
    }

    private fun lokasiLink(): String {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return ""
        val lm = getSystemService(LocationManager::class.java) ?: return ""
        val loc = listOf("gps", "network", "passive")
            .mapNotNull { try { lm.getLastKnownLocation(it) } catch (e: Exception) { null } }
            .maxByOrNull { it.time } ?: return ""
        return " Lokasi: https://maps.google.com/?q=${loc.latitude},${loc.longitude}"
    }

    private fun mulaiSos() =
        kirimWa(sosRecipients(), "TOLONG! $NAME butuh bantuan sekarang." + lokasiLink(), "pesan tolong")

    private fun kirimLokasi() = showChoices("Kirim lokasi ke keluarga?", listOf(
        Pilihan(R.drawable.ic_check, "Ya, kirim lokasi") {
            val l = lokasiLink()
            if (l.isEmpty()) say("Lokasi belum diketahui. Mohon nyalakan GPS") else kirimWa(sosRecipients(), "$NAME ada di sini.$l", "lokasi")
        }
    ))

    // Semua pesan lewat WhatsApp. Otomatis bila layanan aksesibilitas aktif.
    private fun kirimWa(r: List<Kontak>, teks: String, ket: String) {
        if (r.isEmpty()) { say("Belum ada kontak utama. Tambahkan dulu di menu Keluarga"); return }
        val svc = DaruratService.instance
        if (svc != null) {
            say("Mengirim $ket ke ${r.size} keluarga lewat WhatsApp")
            svc.kirimKeBanyak(r.map { it.nomor }, teks)
        } else {
            say("Tekan tombol kirim hijau di WhatsApp")
            startSafe(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${intl(r[0].nomor)}?text=" + Uri.encode(teks))).setPackage("com.whatsapp"))
        }
    }

    // Bila izin WRITE_SECURE_SETTINGS sudah diberikan lewat ADB (sekali saja), layanan aksesibilitas
    // dinyalakan otomatis, termasuk bila Android mematikannya lagi. Tidak perlu "setelan terbatas".
    private fun aktifkanAksesibilitas() {
        try {
            if (checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") != PackageManager.PERMISSION_GRANTED) return
            val cn = "$packageName/${DaruratService::class.java.name}"
            val now = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
            if (!now.split(":").contains(cn)) {
                Settings.Secure.putString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, if (now.isEmpty()) cn else "$now:$cn")
                Settings.Secure.putInt(contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
            }
        } catch (e: Exception) { }
    }

    // ---------- Senter ----------
    private var senterOn = false
    private fun senter() {
        try {
            val cm = getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                ?: run { say("Hp ini tidak punya lampu senter"); return }
            senterOn = !senterOn
            cm.setTorchMode(id, senterOn)
            say(if (senterOn) "Senter menyala" else "Senter mati")
        } catch (e: Exception) { say("Senter tidak bisa dinyalakan") }
    }

    // ================= Wallpaper =================
    private fun pickWallpaper() {
        say("Pilih foto untuk jadi latar")
        try { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), REQ_WP) }
        catch (e: Exception) { say("Tidak ada aplikasi foto") }
    }

    private fun setWallpaperFrom(uri: Uri) {
        Thread {
            val ok = try { contentResolver.openInputStream(uri)?.use { WallpaperManager.getInstance(this).setStream(it) }; true }
            catch (e: Exception) { false }
            runOnUiThread { say(if (ok) "Latar sudah diganti. Cantik sekali" else "Gagal mengganti latar") }
        }.start()
    }

    // ================= Suara =================
    private fun listen() {
        say("Saya mendengarkan, silakan bicara")
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Contoh: telepon Budi")
            // Android 13+: bantu pengenal suara mengenali nama-nama kontak
            if (Build.VERSION.SDK_INT >= 33)
                putStringArrayListExtra(RecognizerIntent.EXTRA_BIASING_STRINGS, ArrayList(loadContacts().map { it.nama }.take(100)))
        }
        try { startActivityForResult(i, REQ_SPEECH) } catch (e: Exception) { say("Pengenal suara tidak tersedia di hp ini") }
    }

    @Deprecated("simple")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (res != RESULT_OK) return
        when (req) {
            REQ_SPEECH -> data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.takeIf { it.isNotEmpty() }?.let { handle(it.toList()) }
            REQ_WP -> data?.data?.let { setWallpaperFrom(it) }
            REQ_PICK -> data?.data?.let { terimaKontak(it) }
        }
    }

    private fun has(t: String, re: String) = Regex(re).containsMatchIn(t)

    private fun handle(alts: List<String>) {
        val t = norm(alts.first())
        status.text = "“${alts.first()}”"
        val contacts = loadContacts()
        when {
            t.matches(Regex("tolong( tolong)*|tolong saya|saya sakit")) || has(t, "darurat") -> confirmSos()
            has(t, "latar|wallpaper") -> pickWallpaper()
            has(t, "salat|solat|sholat|azan|adzan|jadwal") -> showSalat()
            has(t, "keluarga") -> showKeluarga()
            has(t, "aplikasi lain|semua aplikasi") -> showApps()
            has(t, "senter") -> senter()
            has(t, "lokasi") -> kirimLokasi()
            has(t, "tambah|simpan|kontak baru|buat kontak") -> addContact(alts)
            has(t, "ceramah|youtube|kajian|putar") && !has(t, "video call|videocall|\\bvc\\b") -> {
                val q = alts.first().lowercase(locale).let {
                    var r = it
                    listOf("buka", "putarkan", "putar", "youtube", "video", "cari", "tolong", "dong").forEach { w -> r = r.replace(w, " ") }
                    r.replace(Regex("\\s+"), " ").trim()
                }
                say("Membuka ${if (q.isEmpty()) "ceramah" else q}"); youtube(if (q.isEmpty()) "ceramah" else q)
            }
            has(t, "video") -> {
                val strong = rank(alts, contacts).firstOrNull()?.second ?: 0.0
                if (has(t, "call|\\bvc\\b|videocall|\\bwa\\b|whatsapp") || strong >= 0.75) aksi(Aksi.VIDEO, alts, contacts)
                else { say("Membuka video"); youtube(t.replace("video", "").trim().ifEmpty { "ceramah" }) }
            }
            has(t, "pesan|chat|kirim") || (has(t, "whatsapp|\\bwa\\b") && !has(t, "telepon|telpon|telfon|call|panggil|hubungi")) -> {
                if (strip(t).isEmpty()) openPkg("com.whatsapp", "WhatsApp") else aksi(Aksi.CHAT, alts, contacts)
            }
            has(t, "telepon|telpon|telfon|telefon|hubungi|panggil|call") -> aksi(Aksi.TELEPON, alts, contacts)
            has(t, "cari|nomor|berapa|siapa") -> aksi(Aksi.CARI, alts, contacts)
            has(t, "galeri|foto|gambar") -> openGallery()
            has(t, "kamera") -> startSafe(Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
            has(t, "kontak|daftar") -> showContactList(contacts) { showMenu(it) }
            has(t, "jam|hari|tanggal|waktu") ->
                say(SimpleDateFormat("'Sekarang jam' H 'lewat' m 'menit, hari' EEEE, d MMMM yyyy", locale).format(Date()))
            else -> {
                // Mungkin hanya menyebut nama: tampilkan menu kontak itu
                val r = rank(alts, contacts)
                if (r.isNotEmpty() && r[0].second >= 0.85) { say("${r[0].first.nama}. Mau apa?"); showMenu(r[0].first) }
                else {
                    // Mungkin nama aplikasi: "buka maps"
                    val q = norm(alts.first()).replace(Regex("\\b(buka|aplikasi|tolong|dong|ya)\\b"), " ").trim()
                    val sembunyi = disembunyi()
                    val app = semuaApp().filter { it.pkg !in sembunyi }.maxByOrNull { nameScore(q, it.label) }
                    if (q.isNotEmpty() && app != null && nameScore(q, app.label) >= 0.8) { say("Membuka ${app.label}"); openPkg(app.pkg, app.label) }
                    else say("Maaf, belum paham. Coba: telepon Budi, video Budi, atau cari nomor Budi")
                }
            }
        }
    }

    // ================= Aksi umum =================
    private fun startSafe(i: Intent) {
        try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { say("Aplikasinya belum ada di hp ini") }
    }

    private fun openPkg(pkg: String, name: String) {
        packageManager.getLaunchIntentForPackage(pkg)?.let { startSafe(it) } ?: say("$name belum terpasang")
    }

    private fun openGallery() {
        val i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY)
        try { startActivity(i) } catch (e: Exception) { startSafe(Intent(Intent.ACTION_VIEW).setType("image/*")) }
    }

    private fun youtube(q: String) =
        startSafe(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))

    private fun call(num: String) {
        if (num.isBlank()) { say("Nomornya tidak ada"); return }
        val granted = checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        startSafe(Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num))))
    }

    private fun intl(n: String): String {
        val d = n.replace(Regex("[^\\d+]"), "").removePrefix("+")
        return if (d.startsWith("0")) "62" + d.drop(1) else d
    }

    override fun onDestroy() { tts.shutdown(); super.onDestroy() }
}
