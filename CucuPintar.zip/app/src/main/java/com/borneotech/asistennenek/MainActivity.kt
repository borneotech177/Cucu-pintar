package com.borneotech.asistennenek

import android.Manifest
import android.app.Activity
import android.app.WallpaperManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

/**
 * Launcher (layar utama) penuh warna untuk nenek.
 * - Wallpaper hp tampil di belakang tombol; bisa diganti dari tombol "Ganti Latar".
 * - Perintah suara: "putar ceramah ...", "whatsapp <nama>", "telepon <nama>",
 *   "foto", "kamera", "kontak", "ganti latar", "jam berapa", "tolong".
 */
class MainActivity : Activity(), TextToSpeech.OnInitListener {

    companion object { const val NAME = "Nenek" } // ganti sesuai panggilan

    private lateinit var tts: TextToSpeech
    private lateinit var status: TextView
    private lateinit var hello: TextView
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var favBox: LinearLayout
    private val locale = Locale("id", "ID")
    private val REQ_SPEECH = 1
    private val REQ_PERM = 2
    private val REQ_ROLE = 3
    private val REQ_WP = 4
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { updateClock(); handler.postDelayed(this, 10000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.TRANSPARENT
        tts = TextToSpeech(this, this)
        buildUi()
        requestPermissions(
            arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE), REQ_PERM
        )
    }

    override fun onResume() { super.onResume(); handler.post(tick); refreshFavs() }
    override fun onPause() { handler.removeCallbacks(tick); super.onPause() }

    override fun onInit(s: Int) { tts.language = locale; tts.setSpeechRate(0.85f) }

    // Setelah izin dijawab, minta jadikan layar utama (launcher) default
    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == REQ_PERM) { refreshFavs(); askHome() }
    }

    private fun askHome() {
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            val rm = getSystemService(android.app.role.RoleManager::class.java)
            if (rm.isRoleAvailable(android.app.role.RoleManager.ROLE_HOME) &&
                !rm.isRoleHeld(android.app.role.RoleManager.ROLE_HOME)
            ) startActivityForResult(rm.createRequestRoleIntent(android.app.role.RoleManager.ROLE_HOME), REQ_ROLE)
        }
    }

    // Tombol "back" dimatikan supaya nenek tidak tersesat
    @Deprecated("launcher")
    override fun onBackPressed() {}

    private fun say(t: String) { status.text = t; tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "a") }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun updateClock() {
        val d = Date(); val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        hello.text = (if (h < 11) "Selamat pagi" else if (h < 15) "Selamat siang" else if (h < 18) "Selamat sore" else "Selamat malam") + ", $NAME"
        clock.text = SimpleDateFormat("HH:mm", locale).format(d)
        date.text = SimpleDateFormat("EEEE, d MMMM yyyy", locale).format(d)
    }

    // ---------- UI penuh warna ----------
    private fun tile(emoji: String, label: String, c1: String, c2: String, h: Int = 140, onClick: () -> Unit): View =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR, intArrayOf(Color.parseColor(c1), Color.parseColor(c2))
            ).apply { cornerRadius = dp(28).toFloat(); setStroke(dp(3), Color.argb(190, 255, 255, 255)) }
            elevation = dp(6).toFloat()
            layoutParams = LinearLayout.LayoutParams(0, dp(h), 1f).apply { setMargins(dp(6), dp(6), dp(6), dp(6)) }
            addView(TextView(context).apply { text = emoji; textSize = 44f; gravity = Gravity.CENTER })
            addView(TextView(context).apply {
                text = label; textSize = 22f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER; setShadowLayer(5f, 0f, 2f, Color.argb(170, 0, 0, 0))
            })
            isClickable = true
            setOnClickListener { onClick() }
            setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(80).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
                }
                false
            }
        }

    private fun row(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        v.forEach { addView(it) }
    }

    private fun txt(size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        textSize = size; setTextColor(color); gravity = Gravity.CENTER
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setShadowLayer(4f, 0f, 2f, Color.argb(140, 0, 0, 0))
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(28), dp(8), dp(16))
        }
        hello = txt(26f, Color.WHITE, true)
        clock = txt(68f, Color.WHITE, true)
        date = txt(22f, Color.parseColor("#FFF3C4"))
        status = txt(22f, Color.parseColor("#FFE082")).apply { text = "Tekan tombol biru lalu bicara"; setPadding(0, dp(6), 0, 0) }
        root.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(Color.argb(140, 10, 20, 40)); cornerRadius = dp(28).toFloat() }
            setPadding(dp(14), dp(12), dp(14), dp(14))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(6), 0, dp(6), dp(6)) }
            addView(hello); addView(clock); addView(date); addView(status)
        })

        root.addView(row(tile("🎤", "BICARA KE ASISTEN", "#7986CB", "#1A237E", 150) { listen() }))
        // Kontak favorit (bintang) -> tombol telepon & video WhatsApp langsung
        favBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(favBox)
        root.addView(row(
            tile("💬", "WhatsApp", "#25D366", "#0B6B50") { openPkg("com.whatsapp", "WhatsApp") },
            tile("▶️", "YouTube", "#FF5252", "#B71C1C") { openPkg("com.google.android.youtube", "YouTube") }
        ))
        root.addView(row(
            tile("🖼️", "Foto", "#CE93D8", "#6A1B9A") { openGallery() },
            tile("📷", "Kamera", "#F48FB1", "#AD1457") { startSafe(Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }
        ))
        root.addView(row(
            tile("👥", "Kontak", "#FFCC80", "#E65100") { startSafe(Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI)) },
            tile("📞", "Telepon", "#81D4FA", "#01579B") { startSafe(Intent(Intent.ACTION_DIAL)) }
        ))
        root.addView(row(tile("🕌", "PUTAR CERAMAH", "#80CBC4", "#00695C", 130) { youtube("ceramah ustadz terbaru") }))
        root.addView(row(
            tile("🌄", "Ganti Latar", "#C5E1A5", "#33691E", 120) { pickWallpaper() },
            tile("🚨", "TOLONG", "#EF5350", "#B71C1C", 120) { call("112") }
        ))
        // Latar transparan: wallpaper sistem terlihat (lihat tema di manifest)
        setContentView(ScrollView(this).apply { addView(root); isFillViewport = true })
    }

    // ---------- Wallpaper ----------
    private fun pickWallpaper() {
        say("Pilih foto untuk jadi latar")
        try { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), REQ_WP) }
        catch (e: Exception) { say("Tidak ada aplikasi foto") }
    }

    private fun setWallpaperFrom(uri: Uri) {
        Thread {
            val ok = try {
                contentResolver.openInputStream(uri)?.use { WallpaperManager.getInstance(this).setStream(it) }; true
            } catch (e: Exception) { false }
            runOnUiThread { say(if (ok) "Latar sudah diganti. Cantik sekali" else "Gagal mengganti latar") }
        }.start()
    }

    // ---------- Suara ----------
    private fun listen() {
        say("Saya mendengarkan, silakan bicara")
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Silakan bicara")
        }
        try { startActivityForResult(i, REQ_SPEECH) } catch (e: Exception) { say("Pengenal suara tidak tersedia di hp ini") }
    }

    @Deprecated("simple")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (res != RESULT_OK) return
        when (req) {
            REQ_SPEECH -> data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
                ?.let { handle(it.lowercase(locale)) }
            REQ_WP -> data?.data?.let { setWallpaperFrom(it) }
        }
    }

    private fun after(t: String, vararg keys: String): String {
        var r = t
        keys.forEach { r = r.replace(it, " ") }
        return r.replace(Regex("\\s+"), " ").trim()
    }

    private fun handle(t: String) {
        status.text = "“$t”"
        when {
            Regex("tolong|darurat").containsMatchIn(t) -> call("112")
            Regex("latar|wallpaper").containsMatchIn(t) -> pickWallpaper()
            Regex("video").containsMatchIn(t) && !Regex("youtube|ceramah|putar|kajian").containsMatchIn(t) -> {
                val n = after(t, "video", "call", "vc", "whatsapp", "wa", "telepon", "telpon", "panggil", "ke", "tolong")
                if (waCall(n, true)) say("Video WhatsApp ke $n") else say("Video WhatsApp $n tidak ditemukan")
            }
            Regex("ceramah|youtube|video|putar|kajian").containsMatchIn(t) -> {
                val q = after(t, "buka", "putar", "putarkan", "youtube", "video", "tolong", "di", "cari")
                say("Membuka $q"); youtube(if (q.isEmpty()) "ceramah" else q)
            }
            Regex("whatsapp|wa |pesan|chat").containsMatchIn(t) && !Regex("telepon|telpon|call|panggil").containsMatchIn(t) -> {
                val n = after(t, "buka", "whatsapp", "wa", "kirim", "pesan", "chat", "ke", "untuk")
                if (n.isEmpty()) openPkg("com.whatsapp", "WhatsApp")
                else findNumber(n)?.let { say("Membuka WhatsApp $n"); startSafe(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${intl(it)}"))) }
                    ?: say("Kontak $n tidak ditemukan")
            }
            Regex("telepon|telpon|hubungi|call|panggil").containsMatchIn(t) -> {
                val n = after(t, "telepon", "telpon", "hubungi", "call", "panggil", "whatsapp", "wa", "tolong", "ke")
                // Utamakan panggilan WhatsApp; kalau tidak ada, telepon biasa
                if (waCall(n, false)) say("Menelepon $n lewat WhatsApp")
                else findNumber(n)?.let { say("Menelepon $n"); call(it) } ?: say("Kontak $n tidak ditemukan")
            }
            Regex("galeri|foto|gambar").containsMatchIn(t) -> openGallery()
            Regex("kamera").containsMatchIn(t) -> startSafe(Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
            Regex("kontak").containsMatchIn(t) -> startSafe(Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI))
            Regex("jam|hari|tanggal|waktu").containsMatchIn(t) ->
                say(SimpleDateFormat("'Sekarang jam' H 'lewat' m 'menit, hari' EEEE, d MMMM yyyy", locale).format(Date()))
            else -> say("Maaf, coba katakan: putar ceramah, whatsapp nama, atau telepon nama")
        }
    }

    // ---------- Telepon / video WhatsApp langsung ----------
    private fun waCall(name: String, video: Boolean): Boolean {
        if (name.isBlank() || checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return false
        val mime = if (video) "vnd.android.cursor.item/vnd.com.whatsapp.video.call"
                   else "vnd.android.cursor.item/vnd.com.whatsapp.voip.call"
        contentResolver.query(
            ContactsContract.Data.CONTENT_URI, arrayOf(ContactsContract.Data._ID),
            "${ContactsContract.Data.MIMETYPE}=? AND ${ContactsContract.Data.DISPLAY_NAME} LIKE ?",
            arrayOf(mime, "%$name%"), null
        )?.use {
            if (it.moveToFirst()) {
                val uri = Uri.parse("content://com.android.contacts/data/${it.getLong(0)}")
                startSafe(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).setPackage("com.whatsapp"))
                return true
            }
        }
        return false
    }

    private fun refreshFavs() {
        favBox.removeAllViews()
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return
        val names = mutableListOf<String>()
        contentResolver.query(
            ContactsContract.Contacts.CONTENT_URI, arrayOf(ContactsContract.Contacts.DISPLAY_NAME),
            "${ContactsContract.Contacts.STARRED}=1", null, "${ContactsContract.Contacts.DISPLAY_NAME} ASC"
        )?.use { while (it.moveToNext() && names.size < 6) names.add(it.getString(0)) }
        names.forEach { n ->
            favBox.addView(row(
                tile("📞", "Telepon $n", "#66BB6A", "#1B5E20", 110) {
                    if (waCall(n, false)) say("Menelepon $n") else say("WhatsApp $n tidak ditemukan")
                },
                tile("📹", "Video $n", "#42A5F5", "#0D47A1", 110) {
                    if (waCall(n, true)) say("Video call $n") else say("WhatsApp $n tidak ditemukan")
                }
            ))
        }
    }

    // ---------- Aksi ----------
    private fun startSafe(i: Intent) {
        try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { say("Aplikasinya belum ada di hp ini") }
    }

    private fun openPkg(pkg: String, name: String) {
        packageManager.getLaunchIntentForPackage(pkg)?.let { startSafe(it) } ?: say("$name belum terpasang")
    }

    private fun openGallery() {
        val i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY)
        try { startActivity(i) } catch (e: Exception) {
            startSafe(Intent(Intent.ACTION_VIEW).setType("image/*"))
        }
    }

    private fun youtube(q: String) =
        startSafe(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))

    private fun call(num: String) {
        val granted = checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        startSafe(Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:$num")))
    }

    private fun findNumber(name: String): String? {
        if (name.isBlank() || checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null
        )?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    private fun intl(n: String): String {
        val d = n.replace(Regex("[^\\d+]"), "").removePrefix("+")
        return if (d.startsWith("0")) "62" + d.drop(1) else d
    }

    override fun onDestroy() { tts.shutdown(); super.onDestroy() }
}
