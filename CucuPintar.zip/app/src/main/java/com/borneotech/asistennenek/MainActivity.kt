package com.borneotech.asistennenek

import android.Manifest
import android.app.Activity
import android.app.Dialog
import android.app.WallpaperManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.Settings
import android.location.LocationManager
import android.telephony.SmsManager
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

/**
 * Cucu Pintar - launcher untuk nenek.
 * Panggilan utama lewat WhatsApp (suara/video), cadangan telepon biasa.
 * Suara: "telepon Budi", "video Budi", "pesan Budi", "cari nomor Budi",
 *        "tambah nomor Budi 0812...", "putar ceramah ...", "ganti latar", "jam berapa".
 * Kalau nama kurang jelas, aplikasi menampilkan pilihan (tidak menebak).
 */
class MainActivity : Activity(), TextToSpeech.OnInitListener {

    companion object { const val NAME = "Nenek" }

    data class Kontak(val nama: String, val nomor: String)
    data class Pilihan(val ikon: Int, val label: String, val aksi: () -> Unit)
    enum class Aksi { TELEPON, VIDEO, CHAT, CARI }

    private lateinit var tts: TextToSpeech
    private lateinit var status: TextView
    private lateinit var hello: TextView
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var favBox: LinearLayout
    private val locale = Locale("id", "ID")
    private val REQ_SPEECH = 1
    private val REQ_PERM = 2
    private val REQ_ROLE = 3
    private val REQ_WP = 4
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { updateClock(); handler.postDelayed(this, 10000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.TRANSPARENT
        tts = TextToSpeech(this, this)
        buildUi()
        requestPermissions(
            arrayOf(
                Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE,
                Manifest.permission.SEND_SMS, Manifest.permission.ACCESS_FINE_LOCATION
            ), REQ_PERM
        )
    }

    override fun onResume() { super.onResume(); handler.post(tick); refreshFavs() }
    override fun onPause() { handler.removeCallbacks(tick); super.onPause() }
    override fun onInit(s: Int) { tts.language = locale; tts.setSpeechRate(0.85f) }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == REQ_PERM) { refreshFavs(); askHome() }
    }

    private fun askHome() {
        if (Build.VERSION.SDK_INT >= 29) {
            val rm = getSystemService(android.app.role.RoleManager::class.java)
            if (rm.isRoleAvailable(android.app.role.RoleManager.ROLE_HOME) &&
                !rm.isRoleHeld(android.app.role.RoleManager.ROLE_HOME)
            ) startActivityForResult(rm.createRequestRoleIntent(android.app.role.RoleManager.ROLE_HOME), REQ_ROLE)
        }
    }

    @Deprecated("launcher")
    override fun onBackPressed() {}

    private fun say(t: String) { status.text = t; tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "a") }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun hasContacts() = checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    private fun updateClock() {
        val d = Date(); val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        hello.text = (if (h < 11) "Selamat pagi" else if (h < 15) "Selamat siang" else if (h < 18) "Selamat sore" else "Selamat malam") + ", $NAME"
        clock.text = SimpleDateFormat("HH:mm", locale).format(d)
        date.text = SimpleDateFormat("EEEE, d MMMM yyyy", locale).format(d)
    }

    // ================= UI =================
    private fun tile(icon: Int, label: String, c1: String, c2: String, h: Int = 130, wide: Boolean = false, onClick: () -> Unit): View =
        LinearLayout(this).apply {
            orientation = if (wide) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR, intArrayOf(Color.parseColor(c1), Color.parseColor(c2))
            ).apply { cornerRadius = dp(26).toFloat(); setStroke(dp(1), Color.argb(70, 255, 255, 255)) }
            elevation = dp(4).toFloat()
            layoutParams = (if (wide) LinearLayout.LayoutParams(-1, dp(h)) else LinearLayout.LayoutParams(0, dp(h), 1f))
                .apply { setMargins(dp(6), dp(6), dp(6), dp(6)) }
            setPadding(dp(12), dp(8), dp(12), dp(8))
            val sz = if (wide) 52 else 56
            addView(ImageView(context).apply {
                setImageResource(icon)
                setPadding(dp(12), dp(12), dp(12), dp(12))
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.argb(60, 255, 255, 255)) }
                layoutParams = LinearLayout.LayoutParams(dp(sz), dp(sz)).apply { if (wide) rightMargin = dp(14) else bottomMargin = dp(8) }
            })
            addView(TextView(context).apply {
                text = label; textSize = if (wide) 22f else 19f; setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            })
            isClickable = true
            setOnClickListener { onClick() }
            setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(80).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
                }
                false
            }
        }

    private fun row(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        v.forEach { addView(it) }
    }

    private fun txt(size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        textSize = size; setTextColor(color); gravity = Gravity.CENTER
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setShadowLayer(4f, 0f, 2f, Color.argb(140, 0, 0, 0))
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(28), dp(10), dp(20)) }
        hello = TextView(this).apply {
            textSize = 18f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        clock = TextView(this).apply {
            textSize = 56f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }
        date = TextView(this).apply { textSize = 16f; setTextColor(Color.parseColor("#E6EEF8")); gravity = Gravity.CENTER }
        status = TextView(this).apply {
            textSize = 18f; setTextColor(Color.parseColor("#FFE9A8")); gravity = Gravity.CENTER
            text = "Tekan tombol ungu, lalu bilang: “telepon Budi”"; setPadding(dp(8), dp(10), dp(8), 0)
        }
        root.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(Color.argb(120, 12, 18, 40)); cornerRadius = dp(30).toFloat() }
            setPadding(dp(16), dp(14), dp(16), dp(16))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(6), 0, dp(6), dp(8)) }
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                addView(ImageView(context).apply {
                    setImageResource(R.drawable.logo_cucu_pintar)
                    layoutParams = LinearLayout.LayoutParams(dp(96), dp(96)).apply { rightMargin = dp(12) }
                })
                addView(LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                    addView(hello); addView(clock); addView(date)
                })
            })
            addView(status)
        })
        root.addView(tile(R.drawable.ic_mic, "Bicara ke Cucu", "#7C6CFF", "#4A3FD8", 96, true) { listen() })
        favBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(favBox)
        root.addView(row(
            tile(R.drawable.ic_chat_bubble, "WhatsApp", "#34C759", "#12894A") { openPkg("com.whatsapp", "WhatsApp") },
            tile(R.drawable.ic_play, "YouTube", "#FF6B6B", "#D7263D") { openPkg("com.google.android.youtube", "YouTube") }
        ))
        root.addView(row(
            tile(R.drawable.ic_photo, "Foto", "#B388FF", "#7C4DFF") { openGallery() },
            tile(R.drawable.ic_camera, "Kamera", "#FF8FB8", "#E0457B") { startSafe(Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }
        ))
        root.addView(row(
            tile(R.drawable.ic_search, "Cari Kontak", "#FFB74D", "#F57C00") { openContactList() },
            tile(R.drawable.ic_person_add, "Tambah Nomor", "#4FC3F7", "#0288D1") { addContact(emptyList()) }
        ))
        root.addView(tile(R.drawable.ic_book, "Putar Ceramah", "#2DB5A5", "#00796B", 84, true) { youtube("ceramah ustadz terbaru") })
        root.addView(row(
            tile(R.drawable.ic_wallpaper, "Ganti Latar", "#A5D66F", "#558B2F", 110) { pickWallpaper() },
            tile(R.drawable.ic_warning, "TOLONG", "#FF5252", "#C62828", 110) { confirmSos() }
        ))
        setContentView(ScrollView(this).apply { addView(root); isFillViewport = true })
    }

    // ---------- Dialog pilihan besar ----------
    private fun showChoices(title: String, items: List<Pilihan>) {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(16), dp(10), dp(10)) }
        box.addView(TextView(this).apply {
            text = title; textSize = 24f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#1F2A44")); setPadding(0, 0, 0, dp(10))
        })
        val pal = listOf("#34C759" to "#12894A", "#4C8DFF" to "#2457D6", "#9B6BFF" to "#6A3DE8", "#FFA040" to "#EF6C00")
        items.forEachIndexed { i, p ->
            val c = pal[i % pal.size]
            box.addView(tile(p.ikon, p.label, c.first, c.second, 76, true) { d.dismiss(); p.aksi() })
        }
        box.addView(tile(R.drawable.ic_close, "Tutup", "#9AA5B1", "#5F6B7A", 64, true) { d.dismiss() })
        d.setContentView(ScrollView(this).apply { addView(box) })
        d.window?.setBackgroundDrawable(GradientDrawable().apply { setColor(Color.parseColor("#F7F9FC")); cornerRadius = dp(28).toFloat() })
        d.window?.setLayout((resources.displayMetrics.widthPixels * 0.94).toInt(), WindowManager.LayoutParams.WRAP_CONTENT)
        d.show()
    }

    private fun showMenu(k: Kontak) = showChoices(k.nama, listOf(
        Pilihan(R.drawable.ic_phone, "Telepon WhatsApp") { doAksi(Aksi.TELEPON, k) },
        Pilihan(R.drawable.ic_videocam, "Video WhatsApp") { doAksi(Aksi.VIDEO, k) },
        Pilihan(R.drawable.ic_chat, "Pesan WhatsApp") { doAksi(Aksi.CHAT, k) },
        Pilihan(R.drawable.ic_phone, "Telepon Biasa") { call(k.nomor) }
    ))

    private fun showContactList(all: List<Kontak>, onPick: (Kontak) -> Unit) {
        if (all.isEmpty()) { say("Kontak belum ada atau belum diizinkan"); return }
        showChoices("Pilih nama", all.map { k -> Pilihan(R.drawable.ic_person, k.nama) { onPick(k) } })
    }

    private fun openContactList() = showContactList(loadContacts()) { showMenu(it) }

    // ================= Kontak & pencocokan nama =================
    private fun loadContacts(): List<Kontak> {
        if (!hasContacts()) return emptyList()
        val out = LinkedHashMap<String, Kontak>()
        contentResolver.query(
            Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER), null, null, "${Phone.DISPLAY_NAME} COLLATE NOCASE ASC"
        )?.use { c ->
            while (c.moveToNext()) {
                val n = c.getString(0) ?: continue
                if (!out.containsKey(n)) out[n] = Kontak(n, c.getString(1) ?: "")
            }
        }
        return out.values.toList()
    }

    private fun norm(s: String) = s.lowercase(locale).replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()

    private fun lev(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var p = d[0]; d[0] = i
            for (j in 1..b.length) {
                val t = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, p + if (a[i - 1] == b[j - 1]) 0 else 1)
                p = t
            }
        }
        return d[b.length]
    }

    private fun sim(a: String, b: String): Double =
        if (a.isEmpty() || b.isEmpty()) 0.0 else 1.0 - lev(a, b).toDouble() / maxOf(a.length, b.length)

    private fun nameScore(q0: String, n0: String): Double {
        val q = norm(q0); val n = norm(n0)
        if (q.isEmpty() || n.isEmpty()) return 0.0
        if (q == n) return 1.0
        val qt = q.split(" "); val nt = n.split(" ")
        val tok = qt.map { t -> nt.maxOf { w -> if (w == t) 1.0 else sim(t, w) } }.average()
        val cap = if (nt.size > qt.size) 0.97 else 1.0
        return maxOf(tok * cap, sim(q, n))
    }

    private val stop = setOf(
        "telepon", "telpon", "telfon", "telefon", "hubungi", "panggil", "call", "video", "vc", "videocall", "whatsapp", "wa",
        "tolong", "ke", "dong", "ya", "mau", "saya", "aku", "pesan", "chat", "kirim", "lewat", "buka", "cari", "carikan",
        "nomor", "nya", "tambah", "simpan", "kontak", "berapa", "siapa", "yang", "di", "untuk", "bisa", "coba", "hp", "baru", "buat"
    )

    private fun strip(t: String) = norm(t).split(" ").filter { it.isNotEmpty() && it !in stop }.joinToString(" ")

    private fun rank(alts: List<String>, all: List<Kontak>): List<Pair<Kontak, Double>> {
        val qs = alts.map { strip(it) }.filter { it.isNotBlank() }.distinct()
        if (qs.isEmpty()) return emptyList()
        return all.map { k -> k to qs.maxOf { nameScore(it, k.nama) } }
            .filter { it.second >= 0.6 }.sortedByDescending { it.second }
    }

    // ================= Aksi pada kontak =================
    private fun ikon(a: Aksi) = when (a) {
        Aksi.TELEPON -> R.drawable.ic_phone; Aksi.VIDEO -> R.drawable.ic_videocam
        Aksi.CHAT -> R.drawable.ic_chat; Aksi.CARI -> R.drawable.ic_search
    }

    private fun aksi(a: Aksi, alts: List<String>, contacts: List<Kontak>) {
        if (contacts.isEmpty()) { say("Kontak belum bisa dibaca. Mohon izinkan akses kontak"); return }
        val r = rank(alts, contacts)
        when {
            r.isEmpty() -> { say("Nama tidak ketemu. Silakan pilih dari daftar"); showContactList(contacts) { doAksi(a, it) } }
            r[0].second >= 0.9 && (r.size == 1 || r[1].second < r[0].second - 0.05) -> doAksi(a, r[0].first)
            else -> {
                say("Maksudnya yang mana?")
                showChoices("Pilih nama", r.take(4).map { (k, _) -> Pilihan(ikon(a), k.nama) { doAksi(a, k) } })
            }
        }
    }

    private fun doAksi(a: Aksi, k: Kontak) {
        when (a) {
            Aksi.TELEPON ->
                if (waCall(k.nama, false)) say("Menelepon ${k.nama} lewat WhatsApp")
                else { say("${k.nama} belum punya WhatsApp. Menelepon biasa"); call(k.nomor) }
            Aksi.VIDEO -> if (waCall(k.nama, true)) say("Video call ${k.nama}") else say("${k.nama} belum punya WhatsApp")
            Aksi.CHAT -> { say("Membuka WhatsApp ${k.nama}"); startSafe(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${intl(k.nomor)}"))) }
            Aksi.CARI -> { say("Nomor ${k.nama}: " + k.nomor.filter { it.isDigit() }.toCharArray().joinToString(" ")); showMenu(k) }
        }
    }

    // Panggilan WhatsApp langsung lewat data kontak milik WhatsApp
    private fun waCall(name: String, video: Boolean): Boolean {
        if (name.isBlank() || !hasContacts()) return false
        val mime = if (video) "vnd.android.cursor.item/vnd.com.whatsapp.video.call"
                   else "vnd.android.cursor.item/vnd.com.whatsapp.voip.call"
        for (op in listOf("=", "LIKE")) {
            val arg = if (op == "=") name else "%$name%"
            contentResolver.query(
                ContactsContract.Data.CONTENT_URI, arrayOf(ContactsContract.Data._ID),
                "${ContactsContract.Data.MIMETYPE}=? AND ${ContactsContract.Data.DISPLAY_NAME} $op ?", arrayOf(mime, arg), null
            )?.use {
                if (it.moveToFirst()) {
                    val uri = Uri.parse("content://com.android.contacts/data/${it.getLong(0)}")
                    startSafe(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).setPackage("com.whatsapp"))
                    return true
                }
            }
        }
        return false
    }

    // Tambah nomor: nama/nomor dari ucapan diisi otomatis, tinggal tekan Simpan
    private fun addContact(alts: List<String>) {
        val words = mapOf("nol" to "0", "kosong" to "0", "satu" to "1", "dua" to "2", "tiga" to "3", "empat" to "4",
            "lima" to "5", "enam" to "6", "tujuh" to "7", "delapan" to "8", "sembilan" to "9")
        var s = (alts.firstOrNull() ?: "").lowercase(locale)
        words.forEach { (w, d) -> s = s.replace(Regex("\\b$w\\b"), d) }
        val m = Regex("\\+?\\d[\\d\\s\\-]{6,}\\d").find(s)
        val num = m?.value?.replace(Regex("[^\\d+]"), "") ?: ""
        val name = strip(if (m != null) s.removeRange(m.range) else s).split(" ")
            .joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }.trim()
        say(if (num.isNotEmpty()) "Menambah $name, nomor " + num.toCharArray().joinToString(" ") + ". Tekan simpan"
            else "Silakan isi nama dan nomor, lalu tekan simpan")
        val i = Intent(ContactsContract.Intents.Insert.ACTION).setType(ContactsContract.RawContacts.CONTENT_TYPE)
        if (name.isNotBlank()) i.putExtra(ContactsContract.Intents.Insert.NAME, name)
        if (num.isNotEmpty()) i.putExtra(ContactsContract.Intents.Insert.PHONE, num)
        startSafe(i)
    }

    // Kontak favorit (bintang) jadi tombol telepon & video WhatsApp langsung
    private fun refreshFavs() {
        favBox.removeAllViews()
        if (!hasContacts()) return
        val names = mutableListOf<String>()
        contentResolver.query(
            ContactsContract.Contacts.CONTENT_URI, arrayOf(ContactsContract.Contacts.DISPLAY_NAME),
            "${ContactsContract.Contacts.STARRED}=1", null, "${ContactsContract.Contacts.DISPLAY_NAME} ASC"
        )?.use { while (it.moveToNext() && names.size < 6) names.add(it.getString(0)) }
        names.forEach { n ->
            val k = Kontak(n, "")
            favBox.addView(row(
                tile(R.drawable.ic_phone, "Telepon $n", "#43C463", "#17803F", 110) { doAksi(Aksi.TELEPON, loadContacts().firstOrNull { it.nama == n } ?: k) },
                tile(R.drawable.ic_videocam, "Video $n", "#4C8DFF", "#2457D6", 110) { doAksi(Aksi.VIDEO, k) }
            ))
        }
    }

    // ================= TOLONG: kirim ke keluarga (kontak berbintang) =================
    private val sosQueue = mutableListOf<Kontak>()
    private var sosText = ""
    private val sosTimeout = Runnable { DaruratService.menunggu = false; nextSos() }

    private fun confirmSos() {
        val items = mutableListOf(
            Pilihan(R.drawable.ic_warning, "Kirim Pesan Tolong") { mulaiSos() },
            Pilihan(R.drawable.ic_phone, "Telepon Darurat 112") { call("112") }
        )
        if (!DaruratService.aktif)
            items.add(Pilihan(R.drawable.ic_check, "Aktifkan kirim otomatis (keluarga)") { startSafe(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        say("Mau minta tolong ke keluarga?")
        showChoices("Minta tolong ke keluarga?", items)
    }

    private fun sosRecipients(): List<Kontak> {
        if (!hasContacts()) return emptyList()
        val out = LinkedHashMap<String, Kontak>()
        contentResolver.query(
            Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER), "${Phone.STARRED}=1", null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val n = c.getString(0) ?: continue
                val p = c.getString(1) ?: continue
                if (!out.containsKey(n)) out[n] = Kontak(n, p)
            }
        }
        return out.values.toList()
    }

    private fun lokasiLink(): String {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return ""
        val lm = getSystemService(LocationManager::class.java) ?: return ""
        val loc = listOf("gps", "network", "passive")
            .mapNotNull { try { lm.getLastKnownLocation(it) } catch (e: Exception) { null } }
            .maxByOrNull { it.time } ?: return ""
        return " Lokasi: https://maps.google.com/?q=${loc.latitude},${loc.longitude}"
    }

    @Suppress("DEPRECATION")
    private fun smsManager(): SmsManager =
        if (Build.VERSION.SDK_INT >= 31) getSystemService(SmsManager::class.java) else SmsManager.getDefault()

    private fun mulaiSos() {
        val r = sosRecipients()
        if (r.isEmpty()) { say("Belum ada keluarga berbintang di kontak. Menelepon 112"); call("112"); return }
        sosText = "TOLONG! $NAME butuh bantuan sekarang." + lokasiLink()
        // 1) SMS otomatis ke semua keluarga (pasti terkirim bila ada pulsa)
        if (checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            val sm = smsManager()
            r.forEach { try { sm.sendMultipartTextMessage(it.nomor, null, sm.divideMessage(sosText), null, null) } catch (e: Exception) { } }
        }
        // 2) WhatsApp: satu per satu (otomatis bila layanan aksesibilitas aktif)
        say("Mengirim pesan tolong ke ${r.size} keluarga")
        sosQueue.clear(); sosQueue.addAll(r)
        DaruratService.selesai = { runOnUiThread { handler.removeCallbacks(sosTimeout); handler.postDelayed({ nextSos() }, 800) } }
        nextSos()
    }

    private fun nextSos() {
        if (sosQueue.isEmpty()) { DaruratService.menunggu = false; say("Pesan tolong sudah dikirim ke keluarga"); return }
        val k = sosQueue.removeAt(0)
        val url = "https://wa.me/${intl(k.nomor)}?text=" + Uri.encode(sosText)
        DaruratService.menunggu = DaruratService.aktif
        startSafe(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.whatsapp"))
        if (DaruratService.aktif) handler.postDelayed(sosTimeout, 9000)
        else { sosQueue.clear(); say("Tekan tombol kirim hijau di WhatsApp") }
    }

    // ================= Wallpaper =================
    private fun pickWallpaper() {
        say("Pilih foto untuk jadi latar")
        try { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), REQ_WP) }
        catch (e: Exception) { say("Tidak ada aplikasi foto") }
    }

    private fun setWallpaperFrom(uri: Uri) {
        Thread {
            val ok = try { contentResolver.openInputStream(uri)?.use { WallpaperManager.getInstance(this).setStream(it) }; true }
            catch (e: Exception) { false }
            runOnUiThread { say(if (ok) "Latar sudah diganti. Cantik sekali" else "Gagal mengganti latar") }
        }.start()
    }

    // ================= Suara =================
    private fun listen() {
        say("Saya mendengarkan, silakan bicara")
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Contoh: telepon Budi")
            // Android 13+: bantu pengenal suara mengenali nama-nama kontak
            if (Build.VERSION.SDK_INT >= 33)
                putStringArrayListExtra(RecognizerIntent.EXTRA_BIASING_STRINGS, ArrayList(loadContacts().map { it.nama }.take(100)))
        }
        try { startActivityForResult(i, REQ_SPEECH) } catch (e: Exception) { say("Pengenal suara tidak tersedia di hp ini") }
    }

    @Deprecated("simple")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (res != RESULT_OK) return
        when (req) {
            REQ_SPEECH -> data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.takeIf { it.isNotEmpty() }?.let { handle(it.toList()) }
            REQ_WP -> data?.data?.let { setWallpaperFrom(it) }
        }
    }

    private fun has(t: String, re: String) = Regex(re).containsMatchIn(t)

    private fun handle(alts: List<String>) {
        val t = norm(alts.first())
        status.text = "“${alts.first()}”"
        val contacts = loadContacts()
        when {
            t.matches(Regex("tolong( tolong)*|tolong saya|saya sakit")) || has(t, "darurat") -> confirmSos()
            has(t, "latar|wallpaper") -> pickWallpaper()
            has(t, "tambah|simpan|kontak baru|buat kontak") -> addContact(alts)
            has(t, "ceramah|youtube|kajian|putar") && !has(t, "video call|videocall|\\bvc\\b") -> {
                val q = alts.first().lowercase(locale).let {
                    var r = it
                    listOf("buka", "putarkan", "putar", "youtube", "video", "cari", "tolong", "dong").forEach { w -> r = r.replace(w, " ") }
                    r.replace(Regex("\\s+"), " ").trim()
                }
                say("Membuka ${if (q.isEmpty()) "ceramah" else q}"); youtube(if (q.isEmpty()) "ceramah" else q)
            }
            has(t, "video") -> {
                val strong = rank(alts, contacts).firstOrNull()?.second ?: 0.0
                if (has(t, "call|\\bvc\\b|videocall|\\bwa\\b|whatsapp") || strong >= 0.75) aksi(Aksi.VIDEO, alts, contacts)
                else { say("Membuka video"); youtube(t.replace("video", "").trim().ifEmpty { "ceramah" }) }
            }
            has(t, "pesan|chat|kirim") || (has(t, "whatsapp|\\bwa\\b") && !has(t, "telepon|telpon|telfon|call|panggil|hubungi")) -> {
                if (strip(t).isEmpty()) openPkg("com.whatsapp", "WhatsApp") else aksi(Aksi.CHAT, alts, contacts)
            }
            has(t, "telepon|telpon|telfon|telefon|hubungi|panggil|call") -> aksi(Aksi.TELEPON, alts, contacts)
            has(t, "cari|nomor|berapa|siapa") -> aksi(Aksi.CARI, alts, contacts)
            has(t, "galeri|foto|gambar") -> openGallery()
            has(t, "kamera") -> startSafe(Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
            has(t, "kontak|daftar") -> showContactList(contacts) { showMenu(it) }
            has(t, "jam|hari|tanggal|waktu") ->
                say(SimpleDateFormat("'Sekarang jam' H 'lewat' m 'menit, hari' EEEE, d MMMM yyyy", locale).format(Date()))
            else -> {
                // Mungkin hanya menyebut nama: tampilkan menu kontak itu
                val r = rank(alts, contacts)
                if (r.isNotEmpty() && r[0].second >= 0.85) { say("${r[0].first.nama}. Mau apa?"); showMenu(r[0].first) }
                else say("Maaf, belum paham. Coba: telepon Budi, video Budi, atau cari nomor Budi")
            }
        }
    }

    // ================= Aksi umum =================
    private fun startSafe(i: Intent) {
        try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { say("Aplikasinya belum ada di hp ini") }
    }

    private fun openPkg(pkg: String, name: String) {
        packageManager.getLaunchIntentForPackage(pkg)?.let { startSafe(it) } ?: say("$name belum terpasang")
    }

    private fun openGallery() {
        val i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY)
        try { startActivity(i) } catch (e: Exception) { startSafe(Intent(Intent.ACTION_VIEW).setType("image/*")) }
    }

    private fun youtube(q: String) =
        startSafe(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))

    private fun call(num: String) {
        if (num.isBlank()) { say("Nomornya tidak ada"); return }
        val granted = checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        startSafe(Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num))))
    }

    private fun intl(n: String): String {
        val d = n.replace(Regex("[^\\d+]"), "").removePrefix("+")
        return if (d.startsWith("0")) "62" + d.drop(1) else d
    }

    override fun onDestroy() { tts.shutdown(); super.onDestroy() }
}
