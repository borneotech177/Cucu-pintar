package com.borneotech.asistennenek

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Menekan tombol "Kirim" di WhatsApp secara otomatis, hanya saat tombol TOLONG
 * sedang mengirim pesan darurat (menunggu = true). Setelah terkirim, kembali ke
 * layar utama (Cucu Pintar) lalu lanjut ke keluarga berikutnya.
 */
class DaruratService : AccessibilityService() {

    companion object {
        @Volatile var aktif = false
        @Volatile var menunggu = false
        @Volatile var selesai: (() -> Unit)? = null
    }

    private val h = Handler(Looper.getMainLooper())

    override fun onServiceConnected() { aktif = true }
    override fun onUnbind(intent: android.content.Intent?): Boolean { aktif = false; return super.onUnbind(intent) }
    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (!menunggu || e?.packageName?.toString() != "com.whatsapp") return
        val root = rootInActiveWindow ?: return
        val btn = root.findAccessibilityNodeInfosByViewId("com.whatsapp:id/send").firstOrNull() ?: cari(root) ?: return
        var n: AccessibilityNodeInfo? = btn
        while (n != null && !n.isClickable) n = n.parent
        if (n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            menunggu = false
            h.postDelayed({ performGlobalAction(GLOBAL_ACTION_HOME); selesai?.invoke() }, 900)
        }
    }

    private fun cari(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val d = n.contentDescription?.toString()?.lowercase()
        if (d == "kirim" || d == "send") return n
        for (i in 0 until n.childCount) n.getChild(i)?.let { c -> cari(c)?.let { return it } }
        return null
    }
}
