package com.borneotech.asistennenek

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Layanan aksesibilitas Cucu Pintar. Hanya bereaksi pada WhatsApp, YouTube, dan notifikasi sistem:
 * 1) Mengirim pesan WhatsApp otomatis ke banyak nomor (TOLONG, kirim lokasi, baterai lemah).
 * 2) Menjawab panggilan WhatsApp dari kontak utama (setelah 2,5 detik).
 * 3) Menekan "Lewati iklan" di YouTube.
 */
class DaruratService : AccessibilityService() {

    companion object {
        @Volatile var instance: DaruratService? = null
        val aktif: Boolean get() = instance != null
    }

    private val h = Handler(Looper.getMainLooper())
    private val antrean = mutableListOf<String>()
    private var teks = ""
    private var menunggu = false
    private var batas: Runnable? = null
    private var akanJawab = false
    private var terakhirSkip = 0L
    private val kataJawab = setOf("jawab", "answer", "terima", "accept")

    private fun sp() = getSharedPreferences("cp", Context.MODE_PRIVATE)

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onInterrupt() {}

    // ---------- 1) Kirim WhatsApp ke banyak nomor ----------
    fun kirimKeBanyak(nomor: List<String>, isi: String) {
        antrean.clear(); antrean.addAll(nomor); teks = isi
        berikut()
    }

    private fun intl(n: String): String {
        val d = n.replace(Regex("[^\\d+]"), "").removePrefix("+")
        return if (d.startsWith("0")) "62" + d.drop(1) else d
    }

    private fun berikut() {
        batas?.let { h.removeCallbacks(it) }
        if (antrean.isEmpty()) { menunggu = false; performGlobalAction(GLOBAL_ACTION_HOME); return }
        val n = antrean.removeAt(0)
        menunggu = true
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${intl(n)}?text=" + Uri.encode(teks)))
                    .setPackage("com.whatsapp").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) { menunggu = false; return }
        val r = Runnable { menunggu = false; berikut() } // tombol kirim tidak ketemu: lanjut ke berikutnya
        batas = r; h.postDelayed(r, 10000)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val pkg = e?.packageName?.toString() ?: return
        when {
            pkg == "com.whatsapp" && menunggu -> cobaKirim()
            pkg == "com.whatsapp" || pkg == "com.android.systemui" -> cobaJawab(pkg)
            pkg == "com.google.android.youtube" -> cobaSkipIklan()
        }
    }

    private fun cobaKirim() {
        val root = akar("com.whatsapp") ?: return
        val btn = root.findAccessibilityNodeInfosByViewId("com.whatsapp:id/send").firstOrNull()
            ?: cariTombol(root, setOf("kirim", "send")) ?: return
        if (klik(btn)) {
            menunggu = false
            batas?.let { h.removeCallbacks(it) }
            h.postDelayed({ berikut() }, 1200)
        }
    }

    // ---------- 2) Jawab panggilan WhatsApp dari kontak utama ----------
    private fun cobaJawab(pkg: String) {
        if (akanJawab || !sp().getBoolean("jawab_otomatis", true)) return
        val root = akar(pkg) ?: return
        val sb = StringBuilder(); kumpulkan(root, sb)
        val s = sb.toString().lowercase()
        if (pkg == "com.android.systemui" && !s.contains("whatsapp")) return
        if (!s.contains("tolak") && !s.contains("decline")) return        // layar panggilan masuk punya tombol Tolak
        if (cariTombol(root, kataJawab) == null) return
        val nama = sp().getStringSet("utama_nama", emptySet()) ?: emptySet()
        if (nama.none { it.isNotBlank() && s.contains(it.lowercase()) }) return // hanya kontak utama
        akanJawab = true
        h.postDelayed({
            akar(pkg)?.let { r -> cariTombol(r, kataJawab)?.let { klik(it) } }
            akanJawab = false
        }, 2500)
    }

    // ---------- 3) Lewati iklan YouTube ----------
    private fun cobaSkipIklan() {
        if (!sp().getBoolean("skip_iklan", true)) return
        val now = SystemClock.uptimeMillis()
        if (now - terakhirSkip < 700) return
        terakhirSkip = now
        val root = akar("com.google.android.youtube") ?: return
        val t = root.findAccessibilityNodeInfosByViewId("com.google.android.youtube:id/skip_ad_button").firstOrNull()
            ?: cariTombol(root, setOf("lewati iklan", "lewati", "skip ad", "skip ads", "skip"))
        klik(t)
    }

    // ---------- alat bantu ----------
    private fun akar(pkg: String): AccessibilityNodeInfo? {
        rootInActiveWindow?.takeIf { it.packageName?.toString() == pkg }?.let { return it }
        return windows.firstNotNullOfOrNull { w -> w.root?.takeIf { it.packageName?.toString() == pkg } }
    }

    private fun klik(n: AccessibilityNodeInfo?): Boolean {
        var x = n
        while (x != null && !x.isClickable) x = x.parent
        return x?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }

    private fun cariTombol(n: AccessibilityNodeInfo, kata: Set<String>): AccessibilityNodeInfo? {
        val a = n.text?.toString()?.trim()?.lowercase()
        val b = n.contentDescription?.toString()?.trim()?.lowercase()
        if ((a != null && a in kata) || (b != null && b in kata)) return n
        for (i in 0 until n.childCount) n.getChild(i)?.let { c -> cariTombol(c, kata)?.let { return it } }
        return null
    }

    private fun kumpulkan(n: AccessibilityNodeInfo, sb: StringBuilder) {
        n.text?.let { sb.append(it).append(' ') }
        n.contentDescription?.let { sb.append(it).append(' ') }
        for (i in 0 until n.childCount) n.getChild(i)?.let { kumpulkan(it, sb) }
    }
}
